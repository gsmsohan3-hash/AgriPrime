import { Router } from 'express';
import { z } from 'zod';
import { requireAuth, AuthRequest } from '../middleware/auth';
import { bkashProvider, nagadProvider } from '../payments/provider';

const router = Router();
router.use(requireAuth);

router.post('/checkout', async (req: AuthRequest, res) => {
  const parsed = z.object({
    provider: z.enum(['BKASH', 'NAGAD']),
    amountPaisa: z.string().regex(/^[1-9][0-9]*$/)
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT' });

  // Deliberately disabled until merchant credentials, legal approvals,
  // signed webhook verification, idempotency and ledger reconciliation exist.
  const provider = parsed.data.provider === 'BKASH' ? bkashProvider : nagadProvider;
  try {
    const checkout = await provider.createCheckout({
      amountPaisa: BigInt(parsed.data.amountPaisa),
      invoiceId: 'NOT_ISSUED',
      callbackUrl: ''
    });
    return res.json(checkout);
  } catch {
    return res.status(503).json({
      error: 'PAYMENT_PROVIDER_NOT_CONFIGURED',
      message: 'Live payments are disabled pending approved merchant integration.'
    });
  }
});

export default router;
