# Production readiness — mandatory before real money

This checklist is not legal advice. Obtain Bangladesh-qualified legal and compliance
advice for the exact business model and confirm requirements with the relevant
regulators and payment providers.

- [ ] Written legal opinion identifying the applicable regulatory permissions.
- [ ] Company formation, tax/VAT, AML/CFT and customer due-diligence obligations reviewed.
- [ ] Investment contract, risk disclosure, refund/withdrawal and complaint policies reviewed.
- [ ] Independent financial model proving the source and sustainability of any distributions.
- [ ] Approved merchant account and written authorization for each payment method.
- [ ] Provider-hosted checkout and server-to-server signed webhook verification.
- [ ] Double-entry ledger with immutable journal entries and reconciliation.
- [ ] Idempotency, replay protection, limits, fraud monitoring and maker-checker approvals.
- [ ] Encryption in transit and at rest; secrets manager; key rotation.
- [ ] Independent penetration test, code review, backup restore test and incident plan.
- [ ] Privacy policy, data retention/deletion policy and consent flows.
- [ ] App-store financial-services policy review.
- [ ] Staged rollout with transaction caps and ongoing independent monitoring.

Never request or store customer bKash/Nagad PINs or OTPs. Never mark a payment
successful based only on an Android client callback or uploaded screenshot.
