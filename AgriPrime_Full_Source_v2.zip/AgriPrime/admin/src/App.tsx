import { useEffect, useState } from 'react';
import { Sprout, LayoutDashboard, Users, ReceiptText, Package, ShieldCheck, LogOut, RefreshCw } from 'lucide-react';

const API = import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000';
type Overview = { users: number; pendingKyc: number; investments: number; pendingTransactions: number };
type User = { id: string; fullName: string; phone: string; status: string; kycStatus: string; createdAt: string };
type Tx = { id: string; userId: string; type: string; status: string; amountPaisa: string; currency: string; createdAt: string };
type PackageRow = { id: string; name: string; description: string; durationDays: number; isPublished: boolean; termsVersion: string };

export default function App() {
  const [token, setToken] = useState('');
  const [inputToken, setInputToken] = useState('');
  const [tab, setTab] = useState('Overview');
  const [overview, setOverview] = useState<Overview | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [txs, setTxs] = useState<Tx[]>([]);
  const [packages, setPackages] = useState<PackageRow[]>([]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function api(path: string) {
    const r = await fetch(`${API}${path}`, { headers: { Authorization: `Bearer ${token}` } });
    const data = await r.json();
    if (!r.ok) throw new Error(data.message || data.error || 'Request failed');
    return data;
  }
  async function load() {
    if (!token) return;
    setBusy(true); setError('');
    try {
      if (tab === 'Overview') setOverview(await api('/api/admin/overview'));
      if (tab === 'Users') setUsers((await api('/api/admin/users')).rows);
      if (tab === 'Transactions') setTxs((await api('/api/admin/transactions')).rows);
      if (tab === 'Packages') setPackages(await api('/api/admin/packages'));
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not load data'); }
    finally { setBusy(false); }
  }
  useEffect(() => { load(); }, [token, tab]);

  if (!token) return <main className="login"><div className="login-card">
    <div className="brand"><Sprout size={34}/><span>AgriPrime</span></div>
    <h1>Admin Console</h1><p>Sign in using an authorized administrator account token.</p>
    <label>Bearer access token</label><input value={inputToken} onChange={e => setInputToken(e.target.value)} placeholder="Paste admin access token" />
    <button onClick={() => setToken(inputToken.trim())} disabled={!inputToken.trim()}>Continue</button>
    <small>Admin access is restricted by the backend ADMIN_USER_IDS allow-list.</small>
  </div></main>;

  const nav = [
    { name: 'Overview', icon: LayoutDashboard }, { name: 'Users', icon: Users },
    { name: 'Transactions', icon: ReceiptText }, { name: 'Packages', icon: Package }
  ];
  return <div className="shell">
    <aside><div className="brand"><Sprout/><span>AgriPrime</span></div><div className="muted">ADMIN CONSOLE</div>
      {nav.map(n => <button className={tab === n.name ? 'nav active' : 'nav'} onClick={() => setTab(n.name)} key={n.name}><n.icon size={18}/>{n.name}</button>)}
      <div className="side-bottom"><ShieldCheck size={17}/> Secure admin session <button className="logout" onClick={() => { setToken(''); setInputToken(''); }}><LogOut size={16}/> Sign out</button></div>
    </aside>
    <main className="content"><header><div><div className="muted">AGRICULTURE FINANCE PLATFORM</div><h1>{tab}</h1></div><button className="refresh" onClick={load}><RefreshCw size={16}/> Refresh</button></header>
      <div className="notice"><ShieldCheck size={18}/><span>Production controls are restricted. Payment settlement and return distribution are not enabled until compliance and provider verification are complete.</span></div>
      {error && <div className="error">{error}</div>}
      {busy && <p className="muted">Loading…</p>}
      {tab === 'Overview' && overview && <div className="cards">
        <Stat title="Registered users" value={overview.users}/><Stat title="Pending KYC" value={overview.pendingKyc}/>
        <Stat title="Investment records" value={overview.investments}/><Stat title="Pending transactions" value={overview.pendingTransactions}/>
      </div>}
      {tab === 'Users' && <Table headers={['Name','Phone','Account','KYC','Created']} rows={users.map(u => [u.fullName,u.phone,u.status,u.kycStatus,new Date(u.createdAt).toLocaleDateString()])}/>}
      {tab === 'Transactions' && <Table headers={['Reference','User ID','Type','Status','Amount','Created']} rows={txs.map(t => [t.id,t.userId,t.type,t.status,`${(Number(t.amountPaisa)/100).toFixed(2)} ${t.currency}`,new Date(t.createdAt).toLocaleString()])}/>}
      {tab === 'Packages' && <Table headers={['Package','Duration','Terms version','Published']} rows={packages.map(p => [p.name,`${p.durationDays} days`,p.termsVersion,p.isPublished ? 'Yes' : 'No'])}/>}
      <footer>AgriPrime • Administrative information only • No financial settlement controls</footer>
    </main>
  </div>;
}
function Stat({ title, value }: { title: string; value: number }) { return <div className="stat"><span>{title}</span><strong>{value.toLocaleString()}</strong></div>; }
function Table({ headers, rows }: { headers: string[]; rows: string[][] }) {
  return <div className="table-wrap"><table><thead><tr>{headers.map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>
    {rows.length ? rows.map((r,i) => <tr key={i}>{r.map((v,j) => <td key={j}>{v}</td>)}</tr>) : <tr><td colSpan={headers.length}>No records found.</td></tr>}
  </tbody></table></div>;
}
