import { Router } from 'express';
import { prisma } from '../server';

const router = Router();

router.get('/', async (_req, res, next) => {
  try {
    const packages = await prisma.package.findMany({
      where: { isPublished: true },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, name: true, description: true,
        minAmountPaisa: true, maxAmountPaisa: true,
        durationDays: true, termsVersion: true
      }
    });
    res.json(packages.map(p => ({
      ...p,
      minAmountPaisa: p.minAmountPaisa.toString(),
      maxAmountPaisa: p.maxAmountPaisa.toString(),
      notice: 'Terms are informational. No return or payout is promised by this API.'
    })));
  } catch (e) { next(e); }
});

export default router;
