import { Router } from 'express';
import { prisma } from '../server';
import { requireAuth, AuthRequest } from '../middleware/auth';

const router = Router();

router.get('/', requireAuth, async (req: AuthRequest, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.userId! },
      select: { id: true, fullName: true, phone: true, status: true, kycStatus: true, createdAt: true }
    });
    if (!user) return res.status(404).json({ error: 'USER_NOT_FOUND' });

    const [investments, transactions] = await Promise.all([
      prisma.investment.findMany({
        where: { userId: user.id },
        include: { package: { select: { name: true, durationDays: true, termsVersion: true } } },
        orderBy: { createdAt: 'desc' }
      }),
      prisma.transaction.findMany({
        where: { userId: user.id },
        select: { id: true, type: true, status: true, amountPaisa: true, currency: true, createdAt: true },
        orderBy: { createdAt: 'desc' },
        take: 20
      })
    ]);

    res.json({
      user,
      investments: investments.map(i => ({ ...i, principalPaisa: i.principalPaisa.toString() })),
      transactions: transactions.map(t => ({ ...t, amountPaisa: t.amountPaisa.toString() })),
      wallet: {
        availableBalancePaisa: '0',
        note: 'Wallet is not activated until regulated ledger and payment integrations are approved.'
      },
      earnings: {
        accruedPaisa: '0',
        note: 'No earnings are calculated or promised by this starter.'
      }
    });
  } catch (e) { next(e); }
});

export default router;
