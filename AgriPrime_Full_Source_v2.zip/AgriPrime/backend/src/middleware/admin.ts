import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth';
import { prisma } from '../server';

export async function requireAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    if (!req.userId) return res.status(401).json({ error: 'UNAUTHORIZED' });
    // Admin access is allow-listed by server configuration until a reviewed RBAC
    // provisioning workflow is deployed. Never trust a client-supplied role.
    const allowList = (process.env.ADMIN_USER_IDS || '').split(',').map(x => x.trim()).filter(Boolean);
    if (!allowList.includes(req.userId)) return res.status(403).json({ error: 'ADMIN_ONLY' });
    const admin = await prisma.user.findUnique({ where: { id: req.userId }, select: { id: true, status: true } });
    if (!admin || admin.status !== 'VERIFIED') return res.status(403).json({ error: 'ADMIN_NOT_VERIFIED' });
    next();
  } catch (e) { next(e); }
}
