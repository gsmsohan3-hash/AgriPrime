# AgriPrime

AgriPrime is a production-oriented starter for an agriculture investment platform.
This repository intentionally does **not** activate real-money deposits, withdrawals,
or fixed-return payouts. Those integrations require legal review, applicable
regulatory authorization, merchant approval, security review, and production secrets.

## Components
- `android/`: Kotlin + Jetpack Compose Android client
- `backend/`: Node.js + Express + Prisma + PostgreSQL API
- `docs/`: production readiness checklist

## Quick start — backend
1. Install Node.js 20+ and PostgreSQL.
2. `cd backend`
3. Copy `.env.example` to `.env` and set `DATABASE_URL` and `JWT_SECRET`.
4. `npm install`
5. `npx prisma generate`
6. `npx prisma migrate dev --name init`
7. `npm run dev`

API base URL: `http://localhost:4000`
Health: `GET /health`
Register: `POST /api/auth/register`
Login: `POST /api/auth/login`
Dashboard: `GET /api/dashboard` (Bearer token)
Packages: `GET /api/packages`

## Quick start — Android
Open `android/` in Android Studio (Giraffe or newer), allow Gradle sync, then run
on an emulator. The sample client uses `http://10.0.2.2:4000` for the Android
emulator. For a physical device, change the base URL to your development machine's
LAN IP. Do not ship cleartext HTTP; configure HTTPS before release.

## Important
- Demo seed packages are informational only and do not promise returns.
- Wallet figures are read-only placeholders until a regulated ledger and payment
  provider integration have been reviewed and approved.
- Never store bKash/Nagad PINs, OTPs, card data, or API secrets in the app.
- Never trust client-submitted payment success, balance, profit, or payout amounts.

## Admin panel
1. `cd admin`
2. Copy `.env.example` to `.env`.
3. `npm install`
4. `npm run dev`
5. Paste a valid admin bearer token. Backend admin routes also require the user ID
   to be present in `ADMIN_USER_IDS` and the account to be VERIFIED.

## Payment integration
See `docs/PAYMENT_INTEGRATION.md`. The bKash/Nagad adapter is deliberately disabled
until approved merchant credentials and current official API specifications are supplied.
