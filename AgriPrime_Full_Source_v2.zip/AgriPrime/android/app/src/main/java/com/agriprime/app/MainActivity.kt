package com.agriprime.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF14532D)
private val Gold = Color(0xFFD6B45A)
private val Page = Color(0xFFF5F7F3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgriPrimeApp() }
    }
}

@Composable
fun AgriPrimeApp() {
    var selected by remember { mutableIntStateOf(0) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Forest,
            secondary = Gold,
            background = Page,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Page,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected == 0, { selected = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected == 1, { selected = 1 }, icon = { Icon(Icons.Default.Spa, null) }, label = { Text("Plans") })
                    NavigationBarItem(selected == 2, { selected = 2 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("History") })
                    NavigationBarItem(selected == 3, { selected = 3 }, icon = { Icon(Icons.Default.AccountCircle, null) }, label = { Text("Profile") })
                }
            }
        ) { padding ->
            when (selected) {
                0 -> HomeScreen(Modifier.padding(padding))
                1 -> PlansScreen(Modifier.padding(padding))
                2 -> HistoryScreen(Modifier.padding(padding))
                else -> ProfileScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Spa, null, tint = Forest, modifier = Modifier.size(34.dp))
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("AgriPrime", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Forest)
                    Text("Growing a greener future", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Forest), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("Account overview", color = Color.White.copy(alpha = .8f))
                    Spacer(Modifier.height(10.dp))
                    Text("৳ 0.00", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text("Wallet balance • Not activated", color = Color.White.copy(alpha = .8f))
                    Spacer(Modifier.height(18.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = .25f))
                    Spacer(Modifier.height(12.dp))
                    Text("Your account is ready for verification.", color = Color.White)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("Investments", "0", Modifier.weight(1f))
                SummaryCard("Transactions", "0", Modifier.weight(1f))
            }
        }
        item {
            Text("Getting started", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Forest)
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Complete your profile and identity verification.", fontWeight = FontWeight.SemiBold)
                    Text("Investment and payment services will be enabled only after the required approvals and secure provider integrations are completed.", color = Color.Gray)
                    Text("No guaranteed return is offered in this app.", color = Forest, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Color.Gray)
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Forest)
        }
    }
}

@Composable
fun PlansScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Investment plans", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Forest)
        Text("Review the project terms and risk disclosures before considering any investment.")
        PlanCard("Agri Starter", "Agriculture project information", "Terms and eligibility pending review")
        PlanCard("Agri Growth", "Agriculture project information", "Terms and eligibility pending review")
        PlanCard("Agri Prime", "Agriculture project information", "Terms and eligibility pending review")
    }
}

@Composable
fun PlanCard(name: String, description: String, status: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(name, color = Forest, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(description)
            Text(status, color = Color(0xFF8A6418), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun HistoryScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("Transaction history", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Forest)
        Spacer(Modifier.height(12.dp))
        Text("No transactions yet.")
    }
}

@Composable
fun ProfileScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("My profile", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Forest)
        Text("Identity verification: Not submitted")
        Text("Account status: Pending")
        Text("Support: support@agriprime.example")
    }
}
