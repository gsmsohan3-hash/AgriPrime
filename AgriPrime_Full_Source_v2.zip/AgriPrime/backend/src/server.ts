import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { PrismaClient } from '@prisma/client';
import authRouter from './routes/auth';
import packageRouter from './routes/packages';
import dashboardRouter from './routes/dashboard';
import adminRouter from './routes/admin';
import paymentsRouter from './routes/payments';

const app = express();
export const prisma = new PrismaClient();

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') ?? false }));
app.use(express.json({ limit: '32kb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 120 }));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'agriprime-api' }));
app.use('/api/auth', authRouter);
app.use('/api/packages', packageRouter);
app.use('/api/dashboard', dashboardRouter);
app.use('/api/admin', adminRouter);
app.use('/api/payments', paymentsRouter);

app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(500).json({ error: 'INTERNAL_ERROR', message: 'An unexpected error occurred.' });
});

const port = Number(process.env.PORT || 4000);
app.listen(port, () => console.log(`AgriPrime API listening on ${port}`));
