import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { prisma } from '../server';

const router = Router();
const registerSchema = z.object({
  fullName: z.string().trim().min(2).max(80),
  phone: z.string().regex(/^\+?[0-9]{10,15}$/),
  password: z.string().min(10).max(72)
});
const loginSchema = z.object({
  phone: z.string().regex(/^\+?[0-9]{10,15}$/),
  password: z.string().min(1).max(72)
});

function tokenFor(id: string) {
  const secret = process.env.JWT_SECRET;
  if (!secret || secret.length < 32) throw new Error('JWT_SECRET must be at least 32 characters');
  return jwt.sign({}, secret, { subject: id, expiresIn: '2h' });
}

router.post('/register', async (req, res, next) => {
  try {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT', details: parsed.error.flatten() });
    const { fullName, phone, password } = parsed.data;
    const exists = await prisma.user.findUnique({ where: { phone } });
    if (exists) return res.status(409).json({ error: 'PHONE_ALREADY_REGISTERED' });
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({ data: { fullName, phone, passwordHash } });
    return res.status(201).json({ token: tokenFor(user.id), user: { id: user.id, fullName, phone, status: user.status, kycStatus: user.kycStatus } });
  } catch (e) { next(e); }
});

router.post('/login', async (req, res, next) => {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT' });
    const user = await prisma.user.findUnique({ where: { phone: parsed.data.phone } });
    if (!user || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) {
      return res.status(401).json({ error: 'INVALID_CREDENTIALS' });
    }
    if (user.status === 'SUSPENDED') return res.status(403).json({ error: 'ACCOUNT_SUSPENDED' });
    return res.json({ token: tokenFor(user.id), user: { id: user.id, fullName: user.fullName, phone: user.phone, status: user.status, kycStatus: user.kycStatus } });
  } catch (e) { next(e); }
});

export default router;
