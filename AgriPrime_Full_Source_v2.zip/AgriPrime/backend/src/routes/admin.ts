import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../server';
import { requireAuth, AuthRequest } from '../middleware/auth';
import { requireAdmin } from '../middleware/admin';

const router = Router();
router.use(requireAuth, requireAdmin);

router.get('/overview', async (_req, res, next) => {
  try {
    const [users, pendingKyc, investments, pendingTransactions] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { kycStatus: 'PENDING' } }),
      prisma.investment.count(),
      prisma.transaction.count({ where: { status: 'PENDING' } })
    ]);
    res.json({ users, pendingKyc, investments, pendingTransactions });
  } catch (e) { next(e); }
});

router.get('/users', async (req, res, next) => {
  try {
    const page = Math.max(1, Number(req.query.page || 1));
    const take = Math.min(50, Math.max(1, Number(req.query.take || 20)));
    const rows = await prisma.user.findMany({
      skip: (page - 1) * take, take, orderBy: { createdAt: 'desc' },
      select: { id: true, fullName: true, phone: true, status: true, kycStatus: true, createdAt: true }
    });
    res.json({ page, take, rows });
  } catch (e) { next(e); }
});

router.get('/transactions', async (req, res, next) => {
  try {
    const page = Math.max(1, Number(req.query.page || 1));
    const take = Math.min(50, Math.max(1, Number(req.query.take || 20)));
    const rows = await prisma.transaction.findMany({
      skip: (page - 1) * take, take, orderBy: { createdAt: 'desc' },
      select: { id: true, userId: true, type: true, status: true, amountPaisa: true, currency: true, providerReference: true, createdAt: true }
    });
    res.json({ page, take, rows: rows.map(x => ({ ...x, amountPaisa: x.amountPaisa.toString() })) });
  } catch (e) { next(e); }
});

router.get('/packages', async (_req, res, next) => {
  try {
    const rows = await prisma.package.findMany({ orderBy: { createdAt: 'desc' } });
    res.json(rows.map(x => ({ ...x, minAmountPaisa: x.minAmountPaisa.toString(), maxAmountPaisa: x.maxAmountPaisa.toString() })));
  } catch (e) { next(e); }
});

const packageSchema = z.object({
  name: z.string().min(2).max(80),
  description: z.string().min(5).max(1000),
  minAmountPaisa: z.string().regex(/^[1-9][0-9]*$/),
  maxAmountPaisa: z.string().regex(/^[1-9][0-9]*$/),
  durationDays: z.number().int().min(1).max(3650),
  termsVersion: z.string().min(1).max(40),
  isPublished: z.boolean().default(false)
});

router.post('/packages', async (req: AuthRequest, res, next) => {
  try {
    const parsed = packageSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT', details: parsed.error.flatten() });
    if (BigInt(parsed.data.minAmountPaisa) > BigInt(parsed.data.maxAmountPaisa)) {
      return res.status(400).json({ error: 'MIN_EXCEEDS_MAX' });
    }
    const p = await prisma.package.create({ data: {
      ...parsed.data,
      minAmountPaisa: BigInt(parsed.data.minAmountPaisa),
      maxAmountPaisa: BigInt(parsed.data.maxAmountPaisa)
    }});
    await prisma.auditLog.create({ data: { actorId: req.userId!, action: 'PACKAGE_CREATED', entityType: 'Package', entityId: p.id } });
    res.status(201).json({ ...p, minAmountPaisa: p.minAmountPaisa.toString(), maxAmountPaisa: p.maxAmountPaisa.toString() });
  } catch (e) { next(e); }
});

router.patch('/packages/:id/publish', async (req: AuthRequest, res, next) => {
  try {
    const parsed = z.object({ isPublished: z.boolean() }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT' });
    const p = await prisma.package.update({ where: { id: req.params.id }, data: { isPublished: parsed.data.isPublished } });
    await prisma.auditLog.create({ data: { actorId: req.userId!, action: parsed.data.isPublished ? 'PACKAGE_PUBLISHED' : 'PACKAGE_UNPUBLISHED', entityType: 'Package', entityId: p.id } });
    res.json({ id: p.id, isPublished: p.isPublished });
  } catch (e) { next(e); }
});

export default router;
