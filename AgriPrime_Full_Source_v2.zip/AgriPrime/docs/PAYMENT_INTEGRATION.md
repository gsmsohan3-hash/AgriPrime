# bKash / Nagad integration boundary

The source includes a provider adapter interface and a fail-closed route. It is
not a live integration and must not be represented as one.

To complete a real integration:
1. Obtain written merchant approval and the current official API specification.
2. Obtain sandbox/production credentials directly from the provider's merchant portal.
3. Implement OAuth/token handling, request signing, checkout creation, callback
   validation and server-to-server payment query exactly as the provider specifies.
4. Verify callback signatures and reconcile invoice ID, merchant ID, amount, currency,
   status, timestamp and provider transaction reference on the server.
5. Enforce idempotency and unique provider transaction references in the database.
6. Record immutable double-entry ledger postings in a database transaction only after
   independent provider verification.
7. Add webhook replay protection, rate limits, alerts, reconciliation reports and
   manual exception handling.
8. Complete legal, security and provider certification before enabling production.

Never collect customer wallet PINs/OTPs. Never trust a browser redirect, Android
callback, or payment screenshot as proof of settlement.
