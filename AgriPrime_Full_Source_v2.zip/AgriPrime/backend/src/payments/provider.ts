/**
 * Payment-provider adapter boundary.
 *
 * This intentionally fails closed. Implement against the exact merchant API
 * documentation and credentials issued to your approved business. Do not guess
 * endpoints, sign requests in the client, or accept screenshots/client callbacks
 * as proof of payment.
 */
export type ProviderName = 'BKASH' | 'NAGAD';

export interface CreateCheckoutInput {
  amountPaisa: bigint;
  invoiceId: string;
  callbackUrl: string;
}

export interface VerifiedPayment {
  provider: ProviderName;
  providerReference: string;
  invoiceId: string;
  amountPaisa: bigint;
  currency: 'BDT';
  status: 'SUCCESS' | 'FAILED' | 'PENDING';
}

export interface PaymentProvider {
  createCheckout(input: CreateCheckoutInput): Promise<{ checkoutUrl: string; providerReference: string }>;
  verifyWebhook(rawBody: string, signature: string | undefined): Promise<VerifiedPayment>;
}

export class NotConfiguredProvider implements PaymentProvider {
  constructor(private readonly provider: ProviderName) {}
  async createCheckout(): Promise<never> {
    throw new Error(`${this.provider} merchant integration is not configured. Obtain provider approval and implement from current official API documentation.`);
  }
  async verifyWebhook(): Promise<never> {
    throw new Error(`${this.provider} webhook verification is not configured. No payment can be marked successful.`);
  }
}

export const bkashProvider = new NotConfiguredProvider('BKASH');
export const nagadProvider = new NotConfiguredProvider('NAGAD');
